import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:xml/xml.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MirasApp());
}

const forest = Color(0xFF123D32);
const emerald = Color(0xFF1D5948);
const cream = Color(0xFFF7F3E8);
const gold = Color(0xFFC6A45C);
const ink = Color(0xFF202923);

class MirasApp extends StatelessWidget {
  const MirasApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Мирас - исламская библиотека',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: forest, primary: forest, surface: cream),
        appBarTheme: const AppBarTheme(backgroundColor: cream, foregroundColor: forest, elevation: 0),
        fontFamily: 'Roboto',
      ),
      home: const LibraryPage(),
    );
  }
}

class BookItem {
  final String title;
  final String path;
  final String extension;

  const BookItem({required this.title, required this.path, required this.extension});

  Map<String, dynamic> toJson() => {'title': title, 'path': path, 'extension': extension};
  factory BookItem.fromJson(Map<String, dynamic> json) => BookItem(
        title: json['title'] as String,
        path: json['path'] as String,
        extension: json['extension'] as String,
      );
}

class LibraryPage extends StatefulWidget {
  const LibraryPage({super.key});
  @override
  State<LibraryPage> createState() => _LibraryPageState();
}

class _LibraryPageState extends State<LibraryPage> {
  List<BookItem> books = [];
  bool loading = true;
  String query = '';

  @override
  void initState() {
    super.initState();
    _loadBooks();
  }

  Future<void> _loadBooks() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('miras_books') ?? [];
    final loaded = <BookItem>[];
    for (final item in raw) {
      try {
        final book = BookItem.fromJson(jsonDecode(item) as Map<String, dynamic>);
        if (await File(book.path).exists()) loaded.add(book);
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() {
      books = loaded;
      loading = false;
    });
    await _saveBooks();
  }

  Future<void> _saveBooks() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('miras_books', books.map((b) => jsonEncode(b.toJson())).toList());
  }

  Future<void> _importBook() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx'],
      );
      if (result == null || result.files.single.path == null) return;
      final picked = result.files.single;
      final ext = (picked.extension ?? '').toLowerCase();
      final source = File(picked.path!);
      final appDir = await getApplicationDocumentsDirectory();
      final libraryDir = Directory('${appDir.path}/miras_library');
      if (!await libraryDir.exists()) await libraryDir.create(recursive: true);
      final safeName = '${DateTime.now().millisecondsSinceEpoch}_${picked.name.replaceAll(RegExp(r'[^a-zA-Z0-9А-Яа-я._ -]'), '_')}';
      final destination = await source.copy('${libraryDir.path}/$safeName');
      final book = BookItem(title: picked.name, path: destination.path, extension: ext);
      if (books.any((b) => b.title == book.title && b.path == book.path)) return;
      setState(() => books.insert(0, book));
      await _saveBooks();
      if (mounted) _message('Книга добавлена в библиотеку');
    } catch (e) {
      if (mounted) _message('Не удалось импортировать файл. Попробуй ещё раз.');
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
  }

  Future<void> _openBook(BookItem book) async {
    if (!await File(book.path).exists()) {
      _message('Файл не найден. Удали книгу из библиотеки и добавь снова.');
      return;
    }
    if (book.extension == 'pdf') {
      if (!mounted) return;
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => PdfReaderPage(book: book)));
    } else if (book.extension == 'docx') {
      if (!mounted) return;
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => DocxReaderPage(book: book)));
    } else {
      final result = await OpenFilex.open(book.path);
      if (result.type != ResultType.done && mounted) {
        _message('Для открытия DOC установи совместимое приложение для документов.');
      }
    }
  }

  Future<void> _removeBook(BookItem book) async {
    setState(() => books.remove(book));
    await _saveBooks();
    try { await File(book.path).delete(); } catch (_) {}
    if (mounted) _message('Книга удалена');
  }

  @override
  Widget build(BuildContext context) {
    final visibleBooks = books.where((b) => b.title.toLowerCase().contains(query.toLowerCase())).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.menu_book_rounded, color: gold, size: 27),
          SizedBox(width: 10),
          Text('МИРАС', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 2.2, color: forest)),
        ]),
        actions: [IconButton(onPressed: _importBook, icon: const Icon(Icons.add_rounded), tooltip: 'Добавить книгу')],
      ),
      body: SafeArea(
        child: CustomScrollView(slivers: [
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [forest, emerald], begin: Alignment.topLeft, end: Alignment.bottomRight),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: gold.withValues(alpha: .65), width: 1),
              ),
              child: Stack(children: [
                Positioned(right: -5, top: -18, child: Icon(Icons.auto_awesome, size: 104, color: Colors.white.withValues(alpha: .07))),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('مكتبة العلم', style: TextStyle(color: gold, fontSize: 19, letterSpacing: 1.4)),
                  const SizedBox(height: 12),
                  const Text('Твоя библиотека\nисламских знаний', style: TextStyle(color: cream, fontSize: 25, height: 1.18, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 10),
                  Text('Собирай полезные книги. Читай в своём темпе.', style: TextStyle(color: cream.withValues(alpha: .82), fontSize: 13, height: 1.4)),
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: _importBook,
                    style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: forest, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
                    icon: const Icon(Icons.file_upload_outlined), label: const Text('Добавить книгу', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                ]),
              ]),
            ),
          )),
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 25, 20, 12),
            child: TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: InputDecoration(
                hintText: 'Найти книгу в библиотеке',
                prefixIcon: const Icon(Icons.search_rounded, color: emerald),
                filled: true, fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 15),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
          )),
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(22, 8, 22, 14),
            child: Row(children: [
              const Expanded(child: Text('Мои книги', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: ink))),
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: const Color(0xFFE7E0CD), borderRadius: BorderRadius.circular(20)), child: Text('${books.length}', style: const TextStyle(color: forest, fontWeight: FontWeight.w700))),
            ]),
          )),
          if (loading)
            const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: emerald)))
          else if (visibleBooks.isEmpty)
            SliverFillRemaining(hasScrollBody: false, child: Center(child: Padding(
              padding: const EdgeInsets.fromLTRB(36, 0, 36, 60),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Container(width: 94, height: 94, decoration: BoxDecoration(color: const Color(0xFFE9E3D3), borderRadius: BorderRadius.circular(28)), child: const Icon(Icons.auto_stories_rounded, size: 46, color: emerald)),
                const SizedBox(height: 18),
                Text(query.isEmpty ? 'Здесь начнётся твоя библиотека' : 'Ничего не найдено', textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: forest)),
                const SizedBox(height: 8),
                Text(query.isEmpty ? 'Добавь PDF, DOC или DOCX из памяти телефона. Файлы будут храниться внутри приложения.' : 'Попробуй другое название книги.', textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF6C746D), height: 1.5)),
              ]),
            )))
          else
            SliverPadding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 28), sliver: SliverList(delegate: SliverChildBuilderDelegate((context, index) {
              final book = visibleBooks[index];
              final isPdf = book.extension == 'pdf';
              return Padding(padding: const EdgeInsets.only(bottom: 12), child: Material(
                color: Colors.white,
                borderRadius: BorderRadius.circular(18),
                child: InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _openBook(book),
                  child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [
                    Container(width: 58, height: 72, decoration: BoxDecoration(color: isPdf ? const Color(0xFFE5EBDD) : const Color(0xFFF1E7D0), borderRadius: BorderRadius.circular(12)), child: Icon(isPdf ? Icons.picture_as_pdf_rounded : Icons.description_rounded, size: 30, color: isPdf ? forest : const Color(0xFF99752C))),
                    const SizedBox(width: 14),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(book.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: ink)),
                      const SizedBox(height: 7),
                      Text(book.extension.toUpperCase(), style: const TextStyle(fontSize: 11, letterSpacing: 1.3, fontWeight: FontWeight.w700, color: emerald)),
                      const SizedBox(height: 4),
                      const Text('В личной библиотеке', style: TextStyle(fontSize: 12, color: Color(0xFF747B74))),
                    ])),
                    PopupMenuButton<String>(icon: const Icon(Icons.more_vert, color: Color(0xFF737A72)), onSelected: (v) { if (v == 'remove') _removeBook(book); }, itemBuilder: (_) => const [PopupMenuItem(value: 'remove', child: Text('Удалить из библиотеки'))]),
                  ])),
                ),
              ));
            }, childCount: visibleBooks.length))),
        ]),
      ),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(color: Color(0xFFFCFAF4), border: Border(top: BorderSide(color: Color(0xFFE8E1D2)))),
        padding: const EdgeInsets.fromLTRB(24, 10, 24, 12),
        child: const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _NavItem(icon: Icons.local_library_rounded, label: 'Библиотека', active: true),
          _NavItem(icon: Icons.bookmark_border_rounded, label: 'Закладки'),
          _NavItem(icon: Icons.settings_outlined, label: 'Настройки'),
        ]),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  const _NavItem({required this.icon, required this.label, this.active = false});
  @override
  Widget build(BuildContext context) => Column(mainAxisSize: MainAxisSize.min, children: [
    Icon(icon, color: active ? forest : const Color(0xFF858A82), size: 23),
    const SizedBox(height: 4),
    Text(label, style: TextStyle(fontSize: 11, color: active ? forest : const Color(0xFF858A82), fontWeight: active ? FontWeight.w700 : FontWeight.w500)),
  ]);
}

class PdfReaderPage extends StatelessWidget {
  final BookItem book;
  const PdfReaderPage({super.key, required this.book});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(book.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
    body: PDFView(filePath: book.path, enableSwipe: true, swipeHorizontal: false, autoSpacing: true, pageFling: true, onError: (e) => debugPrint('PDF error: $e')),
  );
}

class DocxReaderPage extends StatefulWidget {
  final BookItem book;
  const DocxReaderPage({super.key, required this.book});
  @override
  State<DocxReaderPage> createState() => _DocxReaderPageState();
}

class _DocxReaderPageState extends State<DocxReaderPage> {
  String? content;
  String? error;

  @override
  void initState() { super.initState(); _readDocx(); }

  Future<void> _readDocx() async {
    try {
      final bytes = await File(widget.book.path).readAsBytes();
      final archive = ZipDecoder().decodeBytes(bytes);
      final xmlFile = archive.findFile('word/document.xml');
      if (xmlFile == null) throw Exception('document.xml not found');
      final xml = XmlDocument.parse(utf8.decode(xmlFile.content as List<int>));
      final paragraphs = <String>[];
      for (final paragraph in xml.findAllElements('w:p')) {
        final line = paragraph.findAllElements('w:t').map((e) => e.innerText).join();
        if (line.trim().isNotEmpty) paragraphs.add(line);
      }
      if (!mounted) return;
      setState(() => content = paragraphs.join('\n\n'));
    } catch (_) {
      if (!mounted) return;
      setState(() => error = 'Не удалось прочитать этот DOCX. Попробуй пересохранить файл в формате DOCX.');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.book.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
    body: content == null && error == null
      ? const Center(child: CircularProgressIndicator(color: emerald))
      : error != null
        ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center)))
        : SelectionArea(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(24, 20, 24, 48), child: Text(content!.isEmpty ? 'В документе не найден текст.' : content!, style: const TextStyle(fontSize: 18, height: 1.75, color: ink)))),
  );
}
